#!/usr/bin/env bash
docker build --no-cache -t "coursera_test:dev" .
