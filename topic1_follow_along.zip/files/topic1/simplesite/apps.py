from django.apps import AppConfig


class SimplesiteConfig(AppConfig):
    name = 'simplesite'
